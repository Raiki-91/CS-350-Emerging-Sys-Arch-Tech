/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/I2C.h>
#include <ti/drivers/Timer.h>
#include <ti/drivers/UART2.h>

/* Driver configuration */
#include "ti_drivers_config.h"

#define DISPLAY(x) UART2_write(uart, &output, x, NULL);

// I2C Global Variables
static const struct {
    uint8_t address;
    uint8_t resultReg;
    char *id;
} sensors[3] = {
    { 0x48, 0x0000, "11X" },
    { 0x49, 0x0000, "116" },
    { 0x41, 0x0001, "006" }
};
uint8_t             txBuffer[1];
uint8_t             rxBuffer[2];
I2C_Transaction     i2cTransaction;

// UART Global Variables
char                output[128];  // Increased buffer size to accommodate longer messages
int                 bytesToSend;

// Driver Handles - Global variables
I2C_Handle      i2c;
UART2_Handle    uart;
Timer_Handle    timer0;

volatile unsigned char TimerFlag = 0;
void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
    TimerFlag = 1;
}

/*
 *  ======== gpioButtonFxn0 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
 */
volatile unsigned char Button0Flag = 0;
void gpioButtonFxn0(uint_least8_t index)
{
    Button0Flag = 1;
}

/*
 *  ======== gpioButtonFxn1 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_1.
 */
volatile unsigned char Button1Flag = 0;
void gpioButtonFxn1(uint_least8_t index)
{
    Button1Flag = 1;
}

void initUART(void)
{
    UART2_Params uartParams;
    size_t bytesRead;
    size_t bytesWritten = 0;
    uint32_t status     = UART2_STATUS_SUCCESS;

    /* Create a UART where the default read and write mode is BLOCKING */
    UART2_Params_init(&uartParams);
    uartParams.baudRate = 115200;

    uart = UART2_open(CONFIG_UART2_0, &uartParams);

    if (uart == NULL)
    {
        /* UART2_open() failed */
        while (1) {}
    }
}

// Make sure you call initUART() before calling this function.
void initI2C(void)
{
    int8_t              i, found;
    I2C_Params          i2cParams;

    DISPLAY(snprintf(output, sizeof(output), "Initializing I2C Driver\n\r"))

    // Init the driver
    I2C_init();

    // Configure the driver
    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_400kHz;  // Set to 400kHz for faster communication

    // Open the driver
    i2c = I2C_open(CONFIG_I2C_0, &i2cParams);
    if (i2c == NULL)
    {
        DISPLAY(snprintf(output, sizeof(output), "Failed to initialize I2C\n\r"))
        while (1);
    }

    DISPLAY(snprintf(output, sizeof(output), "I2C Initialized Successfully\n\r"))

    // Boards were shipped with different sensors.
    // Try to determine which sensor we have.
    // Scan through the possible sensor addresses

    /* Common I2C transaction setup */
    i2cTransaction.writeBuf   = txBuffer;
    i2cTransaction.writeCount = 1;
    i2cTransaction.readBuf    = rxBuffer;
    i2cTransaction.readCount  = 0;

    found = false;
    for (i = 0; i < 3; ++i)
    {
        i2cTransaction.targetAddress = sensors[i].address;
        txBuffer[0] = sensors[i].resultReg;

        DISPLAY(snprintf(output, sizeof(output), "Is this %s? ", sensors[i].id))
        if (I2C_transfer(i2c, &i2cTransaction))
        {
            DISPLAY(snprintf(output, sizeof(output), "Found\n\r"))
            found = true;
            break;
        }
        DISPLAY(snprintf(output, sizeof(output), "No\n\r"))
    }

    if (found)
    {
        DISPLAY(snprintf(output, sizeof(output), "Detected TMP%s I2C address: 0x%x\n\r", sensors[i].id, i2cTransaction.targetAddress))
    }
    else
    {
        DISPLAY(snprintf(output, sizeof(output), "Temperature sensor not found, check connections.\n\r"))
    }
}

void initTimer(void)
{
    Timer_Params    params;

    // Init the driver
    Timer_init();

    // Configure the driver
    Timer_Params_init(&params);
    params.period = 100000;  // 100ms
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;

    // Open the driver
    timer0 = Timer_open(CONFIG_TIMER_0, &params);

    if (timer0 == NULL)
    {
        while (1) {}  // Failed to initialize timer
    }

    if (Timer_start(timer0) == Timer_STATUS_ERROR)
    {
        while (1) {}  // Failed to start timer
    }

    DISPLAY(snprintf(output, sizeof(output), "Timer Configured\n\r"))
}

int16_t readTemp(void)
{
    int16_t temperature = 0;

    i2cTransaction.readCount = 2;
    if (I2C_transfer(i2c, &i2cTransaction))
    {
        temperature = (rxBuffer[0] << 8) | (rxBuffer[1]);
        temperature *= 0.0078125;  // TMP sensor specific conversion

        if (rxBuffer[0] & 0x80)  // If MSB is set, extend the negative sign
        {
            temperature |= 0xF000;
        }
    }
    else
    {
        DISPLAY(snprintf(output, sizeof(output), "Error reading temperature sensor, I2C Status: %d\n\r", i2cTransaction.status));
        DISPLAY(snprintf(output, sizeof(output), "Please check the sensor connections and power.\n\r"));
    }

    return temperature;
}

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    int16_t temperature = 0;
    int16_t setpoint = 25;  // Default set-point temperature
    uint16_t timer = 0;
    uint8_t heat = 0;
    uint32_t seconds = 0;

    /* Initialize drivers */
    GPIO_init();

#ifdef CONFIG_GPIO_TMP_EN
    GPIO_setConfig(CONFIG_GPIO_TMP_EN, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_HIGH);
    sleep(1);  // Allow sensor to power on
#endif

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    /* Install Button callback */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1)
    {
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }

    initUART();  // Initialize UART before calling I2C initialization
    initI2C();
    initTimer();

    DISPLAY(snprintf(output, sizeof(output), "Starting Task Scheduler\n\r"));

    // Task Scheduler Loop
    while (1)
    {
        // Every 200ms check the button flags
        if (Button0Flag) {
            setpoint++;  // Increase set-point
            Button0Flag = 0;  // Reset flag
        }

        if (Button1Flag) {
            setpoint--;  // Decrease set-point
            Button1Flag = 0;  // Reset flag
        }

        // Every 500ms read the temperature and update the LED
        if (timer % 5 == 0) {  // Timer runs every 100ms, so 5 ticks = 500ms
            temperature = readTemp();  // Read the temperature from the sensor

            // Heater control logic
            if (temperature < setpoint) {
                heat = 1;  // Heater on, S=1
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);  // Turn on LED (indicating heater on)
            } else {
                heat = 0;  // Heater off, S=0
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);  // Turn off LED (indicating heater off)
            }
        }

        // Every second output the following to the UART
        if (timer % 10 == 0) {  // 10 ticks = 1 second
            seconds++;  // Increment seconds counter
            DISPLAY(snprintf(output, sizeof(output), "<%02d,%02d,%d,%04d>\n\r", temperature, setpoint, heat, seconds));
        }

        // Wait for the timer period
        while (!TimerFlag) {}  // Wait for timer interrupt
        TimerFlag = 0;  // Reset timer flag
        timer++;  // Increment timer
    }
}

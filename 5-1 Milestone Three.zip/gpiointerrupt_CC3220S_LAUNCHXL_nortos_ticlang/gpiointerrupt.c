#include <stdint.h>
#include <stddef.h>
#include <ti/drivers/GPIO.h>
#include <ti/drivers/Timer.h>
#include "ti_drivers_config.h"

/* Timer and Morse code timings in microseconds */
#define DOT_DURATION 300000       // 300ms for dot
#define DASH_DURATION 300000      // 300ms for dash (same as dot for uniform speed)
#define CHAR_SPACE 300000         // 300ms between characters
#define WORD_SPACE 800000         // 800ms between words
#define CPU_FREQ_MHZ 48           // Assuming 48MHz CPU frequency for CC3220S
#define DELAY_SCALING_FACTOR (CPU_FREQ_MHZ / 3) // Adjust based on CPU speed (loop scaling)

/* Declare the messages as string literals */
const char SOS[] = "SOS";         // String for SOS message
const char OK[] = "OK";           // String for OK message

/* Global variables */
volatile int isSOS = 1;  // Initially set to SOS pattern
volatile int buttonPressed = 0;  // Flag to detect button press

/*
 *  ======== gpioButtonFxn0 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
 *  This interrupt sets the buttonPressed flag, which is detected by the state machine.
 */
void gpioButtonFxn0(uint_least8_t index) {
    /* Set flag when button is pressed */
    buttonPressed = 1;
}

/*
 *  ======== gpioButtonFxn1 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_1.
 */
void gpioButtonFxn1(uint_least8_t index) {
    /* Set flag when button is pressed */
    buttonPressed = 1;
}

/* Busy-wait delay function for accurate timing */
void delay(uint32_t duration) {
    volatile uint32_t cycles = duration * DELAY_SCALING_FACTOR;
    while (cycles > 0) {
        cycles--;  // Decrement the counter until it reaches 0
    }
}

/* Function to blink an LED on/off for a specified duration */
void blinkLED(int led, int duration) {
    GPIO_write(led, CONFIG_GPIO_LED_ON);  // Turn LED on
    delay(duration);                      // Wait for the specified duration
    GPIO_write(led, CONFIG_GPIO_LED_OFF); // Turn LED off
    delay(DOT_DURATION);                  // Short delay between blinks
}

/* State machine for Morse code operation (SOS or OK) */
void blinkMorseCode(const char* message) {
    for (int i = 0; message[i] != '\0'; i++) {
        if (buttonPressed) {
            // If button is pressed, exit loop to allow message toggle
            break;
        }

        if (message[i] == 'S') {
            /* S -> 3 dots (red LED) */
            blinkLED(CONFIG_GPIO_LED_0, DOT_DURATION);  // Red LED (dot)
            blinkLED(CONFIG_GPIO_LED_0, DOT_DURATION);  // Red LED (dot)
            blinkLED(CONFIG_GPIO_LED_0, DOT_DURATION);  // Red LED (dot)
        } else if (message[i] == 'O') {
            /* O -> 3 dashes (green LED) */
            blinkLED(CONFIG_GPIO_LED_1, DASH_DURATION);  // Green LED (dash)
            blinkLED(CONFIG_GPIO_LED_1, DASH_DURATION);  // Green LED (dash)
            blinkLED(CONFIG_GPIO_LED_1, DASH_DURATION);  // Green LED (dash)
        } else if (message[i] == 'K') {
            /* K -> dash-dot-dash (green-red-green) */
            blinkLED(CONFIG_GPIO_LED_1, DASH_DURATION);  // Green LED (dash)
            blinkLED(CONFIG_GPIO_LED_0, DOT_DURATION);   // Red LED (dot)
            blinkLED(CONFIG_GPIO_LED_1, DASH_DURATION);  // Green LED (dash)
        }
        delay(CHAR_SPACE); // Delay between characters
    }
    delay(WORD_SPACE); // Delay between words
}

/*
 *  ======== timerCallback ========
 *  Timer callback function that drives the state machine.
 *  It continuously blinks the current message (SOS or OK) and checks for button presses.
 */
void timerCallback(Timer_Handle myHandle, int_fast16_t status) {
    // Continuously blink the current message until a button is pressed
    if (!buttonPressed) {
        blinkMorseCode(isSOS ? SOS : OK);  // Blink SOS or OK based on current state
    } else {
        /* Toggle between SOS and OK after button press is detected */
        isSOS = !isSOS;      // Toggle message
        buttonPressed = 0;   // Reset button press flag
    }
}

/*
 *  ======== initTimer ========
 *  Function to initialize the timer that drives the state machine.
 */
void initTimer(void) {
    Timer_Handle timer0;
    Timer_Params params;

    Timer_init();  // Initialize timer
    Timer_Params_init(&params);  // Initialize timer parameters
    params.period = 500000; // Set timer period to 500ms
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;  // Set the callback function

    // Open the timer and start it
    timer0 = Timer_open(CONFIG_TIMER_0, &params);
    if (timer0 == NULL) {
        /* Timer initialization failed */
        while (1) {}
    }
    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
        /* Timer start failed */
        while (1) {}
    }
}

/*
 *  ======== mainThread ========
 *  Main thread for the program that initializes all components.
 */
void *mainThread(void *arg0) {
    /* Initialize GPIO drivers */
    GPIO_init();

    /* Ensure both LEDs are off initially */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);  // Red LED off
    GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);  // Green LED off

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);  // Red LED config
    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);  // Green LED config
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);  // Button config

    /* Install Button callback function */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);  // Enable button interrupt

    /*
     *  If there are multiple buttons, set up CONFIG_GPIO_BUTTON_1
     */
    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1) {
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }

    /* Initialize and start the timer that drives the state machine */
    initTimer();

    return (NULL);
}
